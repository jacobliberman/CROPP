
#ifndef _SCCB_BUS_H_
#define _SCCB_BUS_H_

unsigned char vcm_write(unsigned int focus_val);
unsigned char vcm_init(void);
#endif /* _SCCB_BUS_H_ */

/******************* (C) COPYRIGHT 2015 WangBao *****END OF FILE****/
