# Motorized_Focus_Camera
# Usage
```bash
cd RaspberryPi/Motorized_Focus_Camera/C
```
```bash 
make install 
```
```bash 
make 
```
```bash 
./manualFocus
```



 

